"""
Medical Knowledge RAG Chatbot
A healthcare-focused Retrieval-Augmented Generation system
"""

__version__ = "1.0.0"
__author__ = "Group-AH"
__description__ = "Medical Knowledge RAG Chatbot for Healthcare Domain"
