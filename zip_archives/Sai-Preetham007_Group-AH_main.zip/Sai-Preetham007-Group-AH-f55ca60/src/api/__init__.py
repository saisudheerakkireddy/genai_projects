"""
API modules for the FastAPI service
"""
