def test_function():
    return "Hello World"

print("Module loaded")
