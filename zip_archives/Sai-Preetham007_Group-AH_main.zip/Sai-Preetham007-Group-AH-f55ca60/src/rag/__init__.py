"""
RAG (Retrieval-Augmented Generation) modules
"""
