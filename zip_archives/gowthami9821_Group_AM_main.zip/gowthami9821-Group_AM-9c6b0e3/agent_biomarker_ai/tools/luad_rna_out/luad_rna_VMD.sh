#!/bin/bash
vmd luad_rna_out.pdb -e luad_rna.tcl
