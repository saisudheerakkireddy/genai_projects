"""
Utility modules and helper functions
"""
