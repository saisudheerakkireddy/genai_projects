"""
Training modules for Medical Knowledge RAG Chatbot
"""
