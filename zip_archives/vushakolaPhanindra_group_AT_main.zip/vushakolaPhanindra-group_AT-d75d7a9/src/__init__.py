"""
Credit Score Intelligence Package

This package contains modules for credit score prediction, explanation, and API services.
"""

__version__ = "1.0.0"
__author__ = "Credit Score Intelligence Team"
