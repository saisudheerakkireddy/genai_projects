def store_embeddings(chunks, collection_name="default_collection"):
    """Mock function: store embeddings in ChromaDB."""
    print(f"[Embeddings] Storing {len(chunks)} chunks in collection '{collection_name}'.")
