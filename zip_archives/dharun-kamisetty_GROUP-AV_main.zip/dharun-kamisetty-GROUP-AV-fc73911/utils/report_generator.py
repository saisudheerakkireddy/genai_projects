"""
Utility to generate health reports in PDF format
"""
