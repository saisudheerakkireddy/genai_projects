export const firebaseConfig = {
  "projectId": "studio-2309329163-40a1a",
  "appId": "1:437506770075:web:ebd444dfc592d45b9b723e",
  "apiKey": "AIzaSyBeR1qoaLlod1aV6mvuqwL83did2ZpO3Rw",
  "authDomain": "studio-2309329163-40a1a.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "437506770075"
};
