"""
Model definitions and architectures
"""
