import RecipeSuggestions from "@/components/RecipeSuggestions";


export default function RecipesPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      <RecipeSuggestions />
    </div>
  );
} 