#!/bin/bash
pymol luad_rna.pml
